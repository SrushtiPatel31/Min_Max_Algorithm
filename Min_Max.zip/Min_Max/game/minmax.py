import math

def minmax(board, maximizingPlayer, player, opponent):
    if board.winner(player):
        return 1
    elif board.winner(opponent):
        return -1
    elif not board.available_moves():
        return 0

    if maximizingPlayer:
        maxEval = -math.inf
        for move in board.available_moves():
            board.make_move(move, player)
            eval = minmax(board, False, player, opponent)
            board.board[move] = " "
            maxEval = max(maxEval, eval)
        return maxEval
    else:
        minEval = math.inf
        for move in board.available_moves():
            board.make_move(move, opponent)
            eval = minmax(board, True, player, opponent)
            board.board[move] = " "
            minEval = min(minEval, eval)
        return minEval

def best_move(board, player, opponent):
    bestScore = -math.inf
    move = None
    for possible_move in board.available_moves():
        board.make_move(possible_move, player)
        score = minmax(board, False, player, opponent)
        board.board[possible_move] = " "
        if score > bestScore:
            bestScore = score
            move = possible_move

    # If no move found (board full), return None safely
    return move
