class Board:
    def __init__(self):
        self.board = [" " for _ in range(9)]

    def print_board(self):
        for row in [self.board[i*3:(i+1)*3] for i in range(3)]:
            print("| " + " | ".join(row) + " |")

    def available_moves(self):
        return [i for i, spot in enumerate(self.board) if spot == " "]

    def make_move(self, square, letter):
        if self.board[square] == " ":
            self.board[square] = letter
            return True
        return False

    def winner(self, letter):
        # Check rows, columns, diagonals
        for i in range(3):
            if all([self.board[i*3+j] == letter for j in range(3)]):
                return True
            if all([self.board[i+j*3] == letter for j in range(3)]):
                return True
        if self.board[0] == self.board[4] == self.board[8] == letter:
            return True
        if self.board[2] == self.board[4] == self.board[6] == letter:
            return True
        return False
