from game.board import Board
from game.minmax import best_move

class TicTacToe:
    def __init__(self):
        self.board = Board()

    def play(self):
        player = "X"
        opponent = "O"
        while True:
            self.board.print_board()
            if not self.board.available_moves():
                print("It's a tie!")
                break

            # Human move
            move = int(input("Enter your move (0-8): "))
            if self.board.make_move(move, opponent):
                if self.board.winner(opponent):
                    self.board.print_board()
                    print("You win!")
                    break
            else:
                print("Invalid move. Try again.")
                continue

            # AI move
            # AI move
            ai_move = best_move(self.board, player, opponent)
            if ai_move is not None:   # <-- check before using
                self.board.make_move(ai_move, player)
                if self.board.winner(player):
                    self.board.print_board()
                    print("AI wins!")
                    return
            else:
                self.board.print_board()
                print("It's a tie!")
                return
